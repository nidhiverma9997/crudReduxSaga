import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { loadUserStart, deleteUserStart } from "../redux/action/action";
import {
  MDBTable,
  MDBTableHead,
  MDBTableBody,
  MDBBtn,
  MDBIcon,
  MDBTooltip,
  MDBSpinner,
} from "mdb-react-ui-kit";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";

const Home = () => {
  const dispatch = useDispatch();
  const { users, loading, error } = useSelector((state) => state.data);

  useEffect(() => {
    dispatch(loadUserStart());
  }, []);

  // useEffect(() => error && toast.error(error), [error]);

  if (loading) {
    return (
      <MDBSpinner className="mt-5" role="status">
        <span className="visually-hiddan"></span>
      </MDBSpinner>
    );
  }

  const handleDelete = (id) => {
    if (
      window.confirm("Are you sure that you wanted to delete that user... ? ")
    ) {
      dispatch(deleteUserStart(id));
      toast.success("User Deleted Successfully");
      window.location.reload();
    }
  };

  return (
    <>
      <div className="container mt-5">
        <MDBTable>
          <MDBTableHead dark>
            <tr>
              <th scope="col">Id</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Phone</th>
              <th scope="col">Address</th>
              <th scope="col">Action</th>
            </tr>
          </MDBTableHead>
          <MDBTableBody>
            {users &&
              users.map((item, index) => (
                <tr>
                  <td scope="row">{index + 1}</td>
                  <td>{item.name}</td>
                  <td>{item.email}</td>
                  <td>{item.phone}</td>
                  <td>{item.address}</td>
                  <td>
                    <MDBBtn
                      className="m-1"
                      tag="a"
                      color="none"
                      onClick={() => handleDelete(item.id)}
                    >
                      <MDBTooltip title="Delete" tag="a">
                        <MDBIcon
                          fas
                          icon="trash"
                          style={{ color: "#dd4b39", size: "1g" }}
                        />
                      </MDBTooltip>
                    </MDBBtn>
                    {""}
                    <Link
                      to={`/editUser/${item.id}`}
                      className="m-1"
                      tag="a"
                      color="none"
                    >
                      <MDBTooltip title="Edit" tag="a">
                        <MDBIcon
                          fas
                          icon="pen"
                          style={{ color: "#55acee", marginBottom: "6px" }}
                        />
                      </MDBTooltip>
                    </Link>
                    {""}
                    <Link
                      to={`/userInfo/${item.id}`}
                      className="m-1"
                      tag="a"
                      color="none"
                    >
                      <MDBTooltip title="View" tag="a">
                        <MDBIcon
                          fas
                          icon="eye"
                          style={{ color: "#3b5998", marginBottom: "6px" }}
                        />
                      </MDBTooltip>
                    </Link>
                  </td>
                </tr>
              ))}
          </MDBTableBody>
        </MDBTable>
      </div>
    </>
  );
};
export default Home;
