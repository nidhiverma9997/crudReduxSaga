import React from "react";
import { MDBTypography } from "mdb-react-ui-kit";
const AboutUs = () => {
  return (
    <>
      <div className="mt-5">
        <MDBTypography note noteColor="primary">
          Content Writers can write on a range of subjects, which their clients
          can then use to advertise their services or educate consumers on
          relevant topics to their brand. Content Writers can write on a range
          of subjects, which their clients can then use to advertise their
          services or educate consumers on relevant topics to their brand.
        </MDBTypography>
      </div>
    </>
  );
};
export default AboutUs;
