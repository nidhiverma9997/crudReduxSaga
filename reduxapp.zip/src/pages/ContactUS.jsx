import React from "react";

const ContactUS = () => {
  const object1 = {
    a: "somestring",
    b: 42,
    c: false,
  };

  console.log("object1 Key>>", Object.keys(object1));
  const target = { a: 1, b: 'name' };
  const source = { b: 4, c: 5 };
  const returnedTarget = Object.assign(target, source);
  console.log("target>>", target);
  console.log("returnedTarget>>", returnedTarget);

  const person = {
    isHuman: false,
    printIntroduction: function() {
      console.log(`My name is ${this.name}. Am I human? ${this.isHuman}`);
    }
  };
  
  const me = Object.create(person);
  
  me.name = 'Matthew'; // "name" is a property set on "me", but not on "person"
  me.isHuman = true; // inherited properties can be overwritten
  
  me.printIntroduction();
  person.printIntroduction();

  const obj = {
    a: 'somestring',
    b: 42
  };
  
  for (const [key, value] of Object.entries(obj)) {
    console.log(`obj>> ${key}: ${value}`);
  }
  const obj1 = {
    property1: 42,
    numm : 'nkdf'
  };
  
  Object.seal(obj1);
  object1.property1 = 33;
  console.log(object1.property1);
//   delete object1.property1; // cannot delete when sealed
// console.log(object1.property1);

const iterable = new Set([1, 1, 2, 2, 3, 3]);

for (const value of iterable) {
  console.log('value>>',value);
}

const myPromise = new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('foo');
    }, 300);
  });
  return (
    <>
      <h1>Contact US</h1>
    </>
  );
};
export default ContactUS;
