import { combineReducers } from "redux";
import  usersReducer  from "./reducer/reducer";

const rootReducer = combineReducers({
    data: usersReducer,
})
export default rootReducer;
