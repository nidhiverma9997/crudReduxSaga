import "./App.css";
import React from "react";
import { useSelector } from "react-redux";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import AboutUs from "./pages/AboutUs";
import ContactUS from "./pages/ContactUS";
import Home from "./pages/Home";
import ProductUs from "./pages/ProductUs";
import Services from "./pages/Services";
import AddEditUser from "./components/AddEditUser";
import UserInfo from "./components/UserInfo";
import Header from "./pages/Header";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const App = () => {
  const result = useSelector((state) => state.cardData);
  console.log("result>>", result);
  return (
    <>
      <BrowserRouter>
        <div className="App">
          <ToastContainer />
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/productUs" element={<ProductUs />} />
            <Route path="/contactUS" element={<ContactUS />} />
            <Route path="/services" element={<Services />} />
            <Route path="/addUser" element={<AddEditUser />} />
            <Route path="/editUser/:id" element={<AddEditUser />} />
            <Route path="/userInfo/:id" element={<UserInfo />} />
          </Routes>
        </div>
      </BrowserRouter>
    </>
  );
};
export default App;
